# Modelo de jogo

Este jogo tem como premissa básica a composição colaborativa de uma música. Para isso, dois jogadores precisarão coletar artefatos no cenário para compor cada nota de uma música previamente estabelecida.

## Universo

Universo onde os personagens voam.
