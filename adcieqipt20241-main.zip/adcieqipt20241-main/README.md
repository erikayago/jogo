# ADC/IEQ/IPT 2024.1

Projeto de Administração de Redes de Computadores (ADC), Instalação de Equipamentos de Redes (IEQ) e Telefonia IP (IPT), semestre 2024.1. Será usado um [modelo de jogo](jogo-modelo.md) para o desenvolvimento ao longo do semestre.
 
## Equipes

| Equipe | Jogo |
|-|-|
| [Bernardo, Filipe e Vitor Ademir](https://github.com/VFB-Corporation) | [Jogo](https://github.com/VFB-Corporation/JOGO) |
| [Mariana e Vitor Hugo](https://github.com/mvplay-s) | [Pilatus](https://github.com/mvplay-s/Pilatus) |
| [Náthally e Guilherme](https://github.com/vimdoalegrete) | [jogo](https://github.com/vimdoalegrete/jogo) | 
